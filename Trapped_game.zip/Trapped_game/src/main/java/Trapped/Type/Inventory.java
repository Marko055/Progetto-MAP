
package Trapped.type;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author marko
 */


/**
 * Class that creates Inventory list and contains methods relative to that list
 */
public class Inventory{
    private List<TrappedObject> list = new ArrayList<TrappedObject>();

    /**
     *
     * @return
     */
    public List<TrappedObject> getList() {
        return list;
    }

    /**
     *
     * @param list
     */
    public void setList(List<TrappedObject> list) {
        this.list = list;
    }

    /**
     *
     * @param o
     */
    public void add(TrappedObject o) {
        list.add(o);
    }

    /**
     *
     * @param o
     */
    public void remove(TrappedObject o) {
        list.remove(o);
    }
}
