
package Trapped.type;

/**
 *
 * @author marko
 */

/**
 * Enum type class that contains the negligible words by the Parser
 */
public enum LinkingWord {

    /**
     *
     */
    THE,

    /**
     *
     */
    A,

    /**
     *
     */
    AN,

    /**
     *
     */
    IN,

    /**
     *
     */
    ON,

    /**
     *
     */
    BEHIND
}
