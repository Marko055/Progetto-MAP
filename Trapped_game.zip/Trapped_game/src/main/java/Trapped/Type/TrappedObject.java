
package Trapped.type;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author marko
 */


/**
 * Class that creates a list and contains methods relative to objects of type TrappedObject
 */
public class TrappedObject{
    private final int id;

    private String name;

    private String description;
    
    private Set<String> alias;
    
    private boolean openable = false;
    
    private boolean opened = false;

    private boolean pickupable = true;
    
    private boolean disposable = false;
    
    private boolean usable = true;
    
    private int idRoom;
    
    private int idReceiver;

    /**
     *
     * @param id
     */
    public TrappedObject(int id) {
        this.id = id;
    }

    /**
     *
     * @param id
     * @param name
     */
    public TrappedObject(int id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     */
    public TrappedObject(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param idRoom
     */
    public TrappedObject(int id, String name, String description, int idRoom) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.idRoom = idRoom;
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param alias
     */
    public TrappedObject(int id, String name, String description, Set<String> alias) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.alias = alias;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public boolean isPickupable() {
        return pickupable;
    }

    /**
     *
     * @param pickupable
     */
    public void setPickupable(boolean pickupable) {
        this.pickupable = pickupable;
    }

    /**
     *
     * @return
     */
    public boolean isOpenable() {
        return openable;
    }

    /**
     *
     * @param openable
     */
    public void setOpenable(boolean openable) {
        this.openable = openable;
    }
    
    /**
     *
     * @return
     */
    public boolean isOpened() {
		return opened;
	}

    /**
     *
     * @param opened
     */
    public void setOpened(boolean opened) {
		this.opened = opened;
	}

    /**
     *
     * @return
     */
    public Set<String> getAlias() {
        return alias;
    }

    /**
     *
     * @param alias
     */
    public void setAlias(Set<String> alias) {
        this.alias = alias;
    }
    
    /**
     *
     * @param alias
     */
    public void setAlias(String[] alias) {
        this.alias = new HashSet<String>(Arrays.asList(alias));
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @return
     */
    public int getIdRoom() {
		return idRoom;
	}

    /**
     *
     * @return
     */
    public boolean isDisposable() {
		return disposable;
	}

    /**
     *
     * @param disposable
     */
    public void setDisposable(boolean disposable) {
		this.disposable = disposable;
	}

    /**
     *
     * @return
     */
    public boolean isUsable() {
		return usable;
	}

    /**
     *
     * @param usable
     */
    public void setUsable(boolean usable) {
		this.usable = usable;
	}

    /**
     *
     * @return
     */
    public int getIdReceiver() {
		return idReceiver;
	}

    /**
     *
     * @param idReceiver
     */
    public void setIdReceiver(int idReceiver) {
		this.idReceiver = idReceiver;
	}

    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TrappedObject other = (TrappedObject) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

}
