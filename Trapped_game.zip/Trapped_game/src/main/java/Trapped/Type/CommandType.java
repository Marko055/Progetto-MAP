
package Trapped.type;

/**
 *
 * @author marko
 */

/**
 * Enum type class that contains usable commands
 */
public enum CommandType {

    /**
     *
     */
    END,

    /**
     *
     */
    NO,

    /**
     *
     */
    YES, 

    /**
     *
     */
    NORTH, 

    /**
     *
     */
    SOUTH, 

    /**
     *
     */
    EAST, 

    /**
     *
     */
    WEST,

    /**
     *
     */
    OPEN, 

    /**
     *
     */
    TAKE, 

    /**
     *
     */
    FIND,

    /**
     *
     */
    USE, 

    /**
     *
     */
    LOOK,

    /**
     *
     */
    POSITION, 

    /**
     *
     */
    EQUIP, 

    /**
     *
     */
    INVENTORY,

    /**
     *
     */
    HIDE,

    /**
     *
     */
    RUN,

    /**
     *
     */
    READ,

    /**
     *
     */
    SAVE,

    /**
     *
     */
    LOAD,

    /**
     *
     */
    COMMANDS   
}
