
package Trapped.type;

/**
 *
 * @author marko
 */

import java.util.ArrayList;
import java.util.List;

/**
 * Class that contains methods relative to objects of type Room
 */
public class Room{
    private final int id;

    private String name;

    private String description;
    
    private String look;

    private boolean visible = true;

    private Room south = null;

    private Room north = null;

    private Room east = null;

    private Room west = null;
    
    private boolean blocked = true;
    
    private String descriptionBlocked;
    
    boolean lightNeeded = false;
    
    private Room unlinkedRoom = null;
    
    private final List<TrappedObject> objects=new ArrayList<TrappedObject>();
    
    /**
     *
     * @param id
     */
    public Room(int id) {
        this.id = id;
    }
    
    /**
     *
     * @param id
     * @param description
     */
    public Room(int id, String description) {
        this.id = id;
        this.description = description;
    }
  
    /**
     *
     * @param id
     * @param name
     * @param description
     */
    public Room(int id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public boolean isVisible() {
        return visible;
    }

    /**
     *
     * @param visible
     */
    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    /**
     *
     * @param blocked
     */
    public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}

    /**
     *
     * @return
     */
    public boolean isBlocked() {
		return blocked;
	}

    /**
     *
     * @return
     */
    public String getDescriptionBlocked() {
		return descriptionBlocked;
	}
	
    /**
     *
     * @param descriptionBlocked
     */
    public void setDescriptionBlocked(String descriptionBlocked) {
		this.descriptionBlocked = descriptionBlocked;
	}

    /**
     *
     * @return
     */
    public int getId() {
		return id;
	}
	
    /**
     *
     * @return
     */
    public Room getSouth() {
        return south;
    }

    /**
     *
     * @param south
     */
    public void setSouth(Room south) {
        this.south = south;
    }

    /**
     *
     * @return
     */
    public Room getNorth() {
        return north;
    }

    /**
     *
     * @param north
     */
    public void setNorth(Room north) {
        this.north = north;
    }

    /**
     *
     * @return
     */
    public Room getEast() {
        return east;
    }

    /**
     *
     * @param east
     */
    public void setEast(Room east) {
        this.east = east;
    }

    /**
     *
     * @return
     */
    public Room getWest() {
        return west;
    }

    /**
     *
     * @param west
     */
    public void setWest(Room west) {
        this.west = west;
    }
    
    /**
     *
     * @param unlinkedRoom
     */
    public void setUnlinkedRoom(Room unlinkedRoom) {
		this.unlinkedRoom = unlinkedRoom;
	}

    /**
     *
     * @return
     */
    public Room getUnlinkedRoom() {
		return unlinkedRoom;
	}

    /**
     *
     * @return
     */
    public List<TrappedObject> getObjects() {
        return objects;
    }
   
    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Room other = (Room) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    /**
     *
     * @return
     */
    public String getLook() {
        return look;
    }
    
    /**
     *
     * @param look
     */
    public void setLook(String look) {
        this.look = look;
    }

    /**
     *
     * @param look
     * @param lightNeeded
     */
    public void setLook(String look, boolean lightNeeded) {
        this.look = look;
        this.lightNeeded = lightNeeded;
    }

    /**
     *
     * @return
     */
    public boolean isLightNeeded() {
		return lightNeeded;
	}

    /**
     *
     * @param lightNeeded
     */
    public void setLightNeeded(boolean lightNeeded) {
		this.lightNeeded = lightNeeded;
	}
    
}
