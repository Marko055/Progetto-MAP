
package Trapped.type;

/**
 *
 * @author marko
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * A class derived from TrappedObject that creates a list of objects of type TrappedObject and contains methods relative to that list
 */
public class TrappedObjectContainer extends TrappedObject{
    
    private List<TrappedObject> list = new ArrayList<TrappedObject>();
    
    /**
     *
     * @param id
     */
    public TrappedObjectContainer(int id) {
        super(id);
    }

    /**
     *
     * @param id
     * @param name
     */
    public TrappedObjectContainer(int id, String name) {
        super(id, name);
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     */
    public TrappedObjectContainer(int id, String name, String description) {
        super(id, name, description);
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param alias
     */
    public TrappedObjectContainer(int id, String name, String description, Set<String> alias) {
        super(id, name, description, alias);
    }

    /**
     *
     * @return
     */
    public List<TrappedObject> getList() {
        return list;
    }

    /**
     *
     * @param list
     */
    public void setList(List<TrappedObject> list) {
        this.list = list;
    }

    /**
     *
     * @param o
     */
    public void add(TrappedObject o) {
        list.add(o);
    }

    /**
     *
     * @param o
     */
    public void remove(TrappedObject o) {
        list.remove(o);
    } 
}
