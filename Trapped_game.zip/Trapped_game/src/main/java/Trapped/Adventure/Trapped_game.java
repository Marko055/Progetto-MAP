
package Trapped.Adventure;

import Trapped.Parser.*;
import Trapped.type.CommandType;
import java.util.Scanner;

import Trapped_.Trapped;

/**
 *
 * @author marko
 */

/**
 * Class that enables running the application on a command line
 */
public class Trapped_game {
    
        private GameDescription game;

	private final Parser parser;

    /**
     *
     * @param game
     */
    public Trapped_game(GameDescription game) {
		this.game = game;
		try {
			this.game.init();
		} catch (Exception ex) {
			System.err.println(ex);
		}
		parser = new Parser();
	}

	/**
	 * Method that manages commands END, SAVE, LOAD and that allows to interpret the command entered by the user as input.
	 */
	public void run() {

		System.out.println("\t\t" + game.getCurrentRoom().getName().toUpperCase());
		System.out.println("\n" + game.getCurrentRoom().getDescription());
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		while (scanner.hasNextLine()) {
			String command = scanner.nextLine();
			ParserOutput p = parser.parse(game.getCurrentRoom(), command, game.getCommands(),
					game.getCurrentRoom().getObjects(), game.getInventory(), game.getLwords());

			System.out.println(game.nextMove(p));
			if (p.isEnd()) {
				System.exit(0);
			}

			if(p.getCommand() != null) {
				if (p.getCommand().getType() == CommandType.END) {
					if (p.getInvObject() != null || p.getObject() != null) {
						System.out.println("Did you mean: exit");
					} else {
						System.out.println("Exiting...");
						break;
					}
				}  
			}
		}
	}
	
	/**
	 * Launch the application
     * @param args
	 */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
		Trapped_game engine = new Trapped_game(new Trapped());
		engine.run();
    }
    
}
