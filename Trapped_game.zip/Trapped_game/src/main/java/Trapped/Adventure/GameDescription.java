
package Trapped.Adventure;

import Trapped.Parser.*;
import Trapped.type.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marko
 */

public abstract class GameDescription{
    
    private final List<Room> rooms = new ArrayList<Room>();

	private final List<Command> commands = new ArrayList<Command>();

	private final List<TrappedObject> inventory = new ArrayList<TrappedObject>();

	private final List<LinkingWord> lwords = new ArrayList<LinkingWord>();

	private Room currentRoom;

	private TrappedObject currentObject;

    /**
     *
     * @return
     */
    public TrappedObject getCurrentObject() {
		return currentObject;
	}

    /**
     *
     * @param currentObject
     */
    public void setCurrentObject(TrappedObject currentObject) {
		this.currentObject = currentObject;
	}

    /**
     *
     * @return
     */
    public List<Room> getRooms() {
		return rooms;
	}

    /**
     *
     * @return
     */
    public List<Command> getCommands() {
		return commands;
	}

    /**
     *
     * @return
     */
    public Room getCurrentRoom() {
		return currentRoom;
	}

    /**
     *
     * @param currentRoom
     */
    public void setCurrentRoom(Room currentRoom) {
		this.currentRoom = currentRoom;
	}

    /**
     *
     * @return
     */
    public List<TrappedObject> getInventory() {
		return inventory;
	}

    /**
     *
     * @return
     */
    public List<LinkingWord> getLwords() {
		return lwords;
	}

    /**
     *
     * @throws Exception
     */
    public abstract void init() throws Exception;

    /**
     *
     * @param p
     * @return
     */
    public abstract String nextMove(ParserOutput p);


}
