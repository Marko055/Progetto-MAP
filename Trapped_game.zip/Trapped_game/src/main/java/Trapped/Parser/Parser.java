

package Trapped.Parser;

import Trapped.type.*;
import java.util.List;


/**
 *
 * @author marko
 */

/**
 * Class that interprets the command entered in input by the user, checking if the objects (TrappedObject, Command) 
 * are present in the lists
 */
public class Parser {
    private int checkForCommand(String token, List<Command> commands) {
		for (int i = 0; i < commands.size(); i++) { 
			if (commands.get(i).getName().equals(token) || commands.get(i).getAlias().contains(token)) {
				return i;
			}
		}
		return -1;
	}

	private int checkForObject(String token, List<TrappedObject> objects) { 
		for (int i = 0; i < objects.size(); i++) {
			if (objects.get(i).getName().equals(token) || objects.get(i).getAlias().contains(token)) {
				return i; 
			}
		}
		return -1;
	}


	private int checkForLinkingWord(String token, List<LinkingWord> lword ) {
		for (int i = 0; i < lword.size(); i++) { 
			if (lword.get(i).equals(token)) {
				return i;
			}
		}
		return -1;
	}

    /**
     *
     * @param room
     * @param command
     * @param commands
     * @param objects
     * @param inventory
     * @param lword
     * @return
     */
    public ParserOutput parse(Room room, String command, List<Command> commands, List<TrappedObject> objects, List<TrappedObject> inventory, List<LinkingWord> lword) {
		String cmd = command.toLowerCase().trim();
		String[] tokens = cmd.split("[\\s']+");
                
		int sizeTokens = tokens.length;
		int ioinv = -1;
		int io = -1;
		int ic = -1;
		
		if (tokens.length > 0) {
			for(int i = 0; i < sizeTokens; i++ ) {

				
				if(checkForLinkingWord(tokens[i], lword) > -1) {
					i++;
				}
				else if (checkForCommand(tokens[i], commands) > -1) {
					ic = checkForCommand(tokens[i], commands); 
				}
				else if (checkForObject(tokens[i], objects) > -1) { 
					io = checkForObject(tokens[i], objects);
				}
				else if (checkForObject(tokens[i], inventory) > -1) { 
					ioinv = checkForObject(tokens[i], inventory);
				}


			
			}
			if (ioinv < 0 && ic > -1 && io < 0) {
				return new ParserOutput(room, commands.get(ic), null, null);
			} else if (io > -1 && ioinv > -1 && ic > -1) {
				return new ParserOutput(room, commands.get(ic), objects.get(io), inventory.get(ioinv));
			} else if (io > -1 && ic > -1 && ioinv < 0) {
				return new ParserOutput(room, commands.get(ic), objects.get(io), null);
			} else if (ioinv > -1 && ic > -1 && io < 0) {
				return new ParserOutput(room, commands.get(ic), null, inventory.get(ioinv));
			}else if(ic < 0 && (io < 0 || ioinv < 0)) {
				return new ParserOutput(null, null, null, null);
			}
			else{
				return new ParserOutput(null, null, null, null);
			}
		} else {
			return null;
		}
	}

}
