
package Trapped.Parser;

import Trapped.type.*;

/**
 *
 * @author marko
 */

/**
 * Class that manages the objects (TrappedObject, Command) inserted in input by the user
 */
public class ParserOutput {
    
    private Command command;

    private TrappedObject object;
    
    private TrappedObject invObject;
   
    private LinkingWord lword;
    
    private boolean end;

    /**
     *
     * @param command
     * @param object
     */
    public ParserOutput(Command command, TrappedObject object) {
        this.command = command;
        this.object = object;
    }

    /**
     *
     * @param room
     * @param command
     * @param object
     * @param invObejct
     */
    public ParserOutput(Room room, Command command, TrappedObject object, TrappedObject invObejct) {
        this.command = command;
        this.object = object;
        this.invObject = invObejct;
    }
    
    /**
     *
     * @param room
     * @param command
     * @param object
     * @param invObejct
     * @param lword
     */
    public ParserOutput(Room room, Command command, TrappedObject object, TrappedObject invObejct, LinkingWord lword) {
        this.command = command;
        this.object = object;
        this.invObject = invObejct;
        this.lword = lword;
    }
    
    /**
     *
     * @return
     */
    public Command getCommand() {
        return command;
    }

    /**
     *
     * @param command
     */
    public void setCommand(Command command) {
        this.command = command;
    }

    /**
     *
     * @return
     */
    public TrappedObject getObject() {
        return object;
    }

    /**
     *
     * @param object
     */
    public void setObject(TrappedObject object) {
        this.object = object;
    }

    /**
     *
     * @return
     */
    public TrappedObject getInvObject() {
        return invObject;
    }

    /**
     *
     * @param invObject
     */
    public void setInvObject(TrappedObject invObject) {
        this.invObject = invObject;
    }

    /**
     *
     * @return
     */
    public LinkingWord getLword() {
		return lword;
	}

    /**
     *
     * @return
     */
    public boolean isEnd() {
		return end;
	}

    /**
     *
     * @param end
     */
    public void setEnd(boolean end) {
		this.end = end;
	}

}
