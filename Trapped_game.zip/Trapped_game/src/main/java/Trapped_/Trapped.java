
package Trapped_;


import Trapped.type.*;
import Trapped.Adventure.*;
import Trapped.Parser.ParserOutput;

/**
 * Class that manages the various commands and that instantiates the objects of classes of package Trapped.type
 */

public class Trapped extends GameDescription {

	boolean keyUsed = false;
        boolean untied = false;
        boolean hidden = false;
        boolean keyTaken = false;
        boolean carKeyInventory = false;
	boolean emptyInventory = true;
	boolean objectEquipped = true; 
	boolean equipped = false;
	boolean stoneUsed = false;

    /**
     *
     * @throws Exception
     */
    @Override


	/**
	 * Class that instantiates objects of type Command, Room, TrappedObject.
	 * It also allows you to create the map and define the properties of the instantiated objects.
	 */
	public void init() throws Exception {
		//Commands
		Command north = new Command(CommandType.NORTH, "north");
		north.setAlias(new String[]{"n", "N", "North", "NORTH","forward"});
		getCommands().add(north);
		Command south = new Command(CommandType.SOUTH, "south");
		south.setAlias(new String[]{"s", "S", "South", "SOUTH","back", "backwards"});
		getCommands().add(south);
		Command east = new Command(CommandType.EAST, "east");
		east.setAlias(new String[]{"e", "E","East","EAST", "right"});
		getCommands().add(east);
		Command west = new Command(CommandType.WEST, "west");
		west.setAlias(new String[]{"w", "W","West","WEST", "left"});
		getCommands().add(west);
		Command position = new Command(CommandType.POSITION, "position");
		position.setAlias(new String[]{"room","where am I","where am I?","Where am I","Where am I?"});
		getCommands().add(position);
		Command end = new Command(CommandType.END, "exit");
		end.setAlias(new String[]{"end", "exit", "leave"});
		getCommands().add(end);
		Command look = new Command(CommandType.LOOK, "look");
		look.setAlias(new String[]{"watch", "observe" , "describe","view","see"});
		getCommands().add(look);
		Command inventory = new Command(CommandType.INVENTORY, "inventory");
		inventory.setAlias(new String[]{"look inventary", "objects","things","stuff"});
		getCommands().add(inventory);
		Command equip= new Command(CommandType.EQUIP, "equip");
		equip.setAlias(new String[]{"take from the inventory"});
		getCommands().add(equip);
		Command take= new Command(CommandType.TAKE, "take");
		take.setAlias(new String[]{"pick up","catch"});
		getCommands().add(take);
		Command use= new Command(CommandType.USE, "use");
		use.setAlias(new String[]{"utilize","utilise","turn","throw","cast","toss","read", "drive"});
		getCommands().add(use);
		Command open = new Command(CommandType.OPEN, "open");
		open.setAlias(new String[]{"unlock"});
		getCommands().add(open);
		Command find= new Command(CommandType.FIND, "find");
		find.setAlias(new String[]{"search for","discover"});
		getCommands().add(find);
		Command yes= new Command(CommandType.YES, "yes");
		yes.setAlias(new String[]{"of course","ok","y","accept","agree to","Yes"});
		getCommands().add(yes);
		Command no= new Command(CommandType.NO, "no");
		no.setAlias(new String[]{"n","refuse","No"});
		getCommands().add(no);
                Command hide = new Command(CommandType.HIDE, "hide");
		hide.setAlias(new String[]{"hide"});
		getCommands().add(hide);
                Command run = new Command(CommandType.RUN, "run");
		run.setAlias(new String[]{"leave","sprint","go"});
		getCommands().add(run);
                Command read = new Command(CommandType.READ, "read");
		read.setAlias(new String[]{});
		getCommands().add(read);
		Command save= new Command(CommandType.SAVE, "save");
		save.setAlias(new String[]{""});
		getCommands().add(save);
		Command load= new Command(CommandType.LOAD, "load");
		load.setAlias(new String[]{});
		getCommands().add(load);
		Command commands= new Command(CommandType.COMMANDS, "commands");
		commands.setAlias(new String[]{"command"});
		getCommands().add(commands);


		//rooms
		Room darkRoom = new Room(0, "Dark Room", "I open my eyes and look around. I was in a pitch-black room tied to a chair without even knowing how I got here.\n"
                                + " The last thing I remember is coming home after a night out with my friends and now I'm stuck here.\n"
                                + "I need to get out of here, I thought. I tried moving my wrists in order to loosen the rope but to no avail. \n"
                                + "\"Hello, is anybody there!?\", I screamed. Silence. I remember putting a small knife in my pocket last night. Maybe it's still there?"
                                + "I reach out to my pocket and to my suprise the knife was still there.\n");
		darkRoom.setLook(" The room was old and rusty. There was a window to my right and a wooden door in front of me. There were cobwebs everywhere.\n"
                                + " The dusty smell made my nose feel tingly. \"Let's just get out of here\". \n", true);
                darkRoom.setLightNeeded(true);

		Room hallway = new Room(1, "Creepy hallawy", "As I exited the room the door slammed shut and I found myself standing in a long, dimly lit hallway.\n"
                                + " Paintings hung up of what looked to be important rich people, their eyes following my every move. The hallway was rather empty except for a big wooden wardrobe that was standing in the corner.\n"
                                + " I started walking and suddenly I froze. I swear I could make out a silhouette of something at the and of the hallway. As i my eyes adjusted to the dark I realized that the silhoutte was slowly approaching me.\n"
                                + "I should find some place to hide\n");
		hallway.setLook("The silhouette is slowly approaching me, I better find some place to hide!\n");
                hallway.setDescriptionBlocked("The door is locked. I can't go out");
                hallway.setBlocked(true);
            

		Room staircase = new Room(2, "Staircase", "As I got to the end of the hallway I reached an old wooden stairway. The upper stairway was probably leading to an attic or a some other room of that kind.\n"
                                + " Suddenly I heard a scraping noise and I whipped around. The upper staircase was dark and I could only see a few meters in front of me. The scraping noise happend again, except this time much closer.\n"
                                + " \"H-hello?\" I asked shakily.\"I-is s-s-someone th-there?\"\n" 
                                + "\"Help me\", the voice said in a rather eerie tone. Should I follow it or not?\n");
		staircase.setLook("I heard a creepy voice calling for help. Should I help it or not?\n");
		staircase.setDescriptionBlocked("There is something coming in my direction. I better hide!\n");
		staircase.setBlocked(true);

		Room livingRoom = new Room(3,"Living Room","\nI went down the stairs and entered into what is supposed to be a living room. I immediately saw the exit but unfortunately the door to the outside was fortified with the wooden boards.\n"
                                + " I expected the living room to be rusty, but I was surprised to find that it was actually fairly organized. A big table made from oak and five chairs filled the room. In the corner was a cupboard  with a set of drawers.\n");
		livingRoom.setLook("The room was organised really well. There was a big table made from oak and five chairs filled the room. In the corner was a cupboard  with a set of drawers.\n");
                livingRoom.setDescriptionBlocked("Someone is calling for help. Should I help them?\n");
		livingRoom.setBlocked(true);
                

		Room backyard = new Room(4,"Backyard","I started running as fast as I could. My heart was pounding and I was breathing shakily. When I stopped to catch my breath I realised I was standing in the backyard of the house.\n"
                        + " In front of me was a tall wire fence. \"Now what\", I said. There is no possible way I can jump over the fence. Maybe I could cut it with something?\n");
		backyard.setLook("I'm standing in a backyard of the house. There is a tall wire fence in front of me.\n" );
		backyard.setDescriptionBlocked("The living room door is shut with wooden boards. I can't get out.\n");
                backyard.setBlocked(true);

		Room forest = new Room(5,"Forest","After running for what felt like an hour I found myself standing next to an old oak tree in the middle of a forest. The forest was dark and foggy and way too quiet.\n"
                                +" Suddenly I heard something snap in the distance. \"Something's coming!\".\n");
		forest.setLook("I'm standing in the middle of a dark forest. Who knows If I'll ever find a way out.\n");
		forest.setDescriptionBlocked("There is a tall wire fence. I need to find a way to get trough it.\n");
                forest.setBlocked(true);

		Room car = new Room(6,"Car Escape","I quickly got up and started walking. Not long after I heard a loud growl in the distance. I turned around and saw that the creature that I had seen before was now chasing me.\n"
                                + "I started running as fast as I could trying to escape it. In the distance I noticed an old car parked behind a tree.\n");
		car.setLook("That thing I saw before is now chasing me!\n");
		car.setDescriptionBlocked("I just heard something snap in the distance. I'm not sure if I should go in the direction of it.\n");
                car.setBlocked(true);

		Room home = new Room(7,"Home"," After about 10 minutes of driving I finally got out of the forest. I realised I was in my neighborhood, right in front of my house.\n"
                                + "\"Finally home\", I exhaled. I got out of the car, opened my front door and got inside. I noticed an envelope standing on my kitchen table.\n");
		home.setLook("There is an envelope on my table. \"Hmm, I wonder what's inside?\"\n");
                home.setDescriptionBlocked("The creature is chasing me. I should try to find a way to escape it!");
		home.setBlocked(true);


                
		//maps
                darkRoom.setNorth(hallway);
		hallway.setSouth(darkRoom);
		hallway.setEast(staircase);
		staircase.setWest(hallway);
		staircase.setSouth(livingRoom);
		livingRoom.setNorth(staircase);
		livingRoom.setEast(backyard);
		backyard.setWest(livingRoom);
		backyard.setNorth(forest);
		forest.setSouth(backyard);
		forest.setNorth(car);
		car.setSouth(forest);
		car.setWest(home);
		home.setEast(car);

		getRooms().add(darkRoom);
		getRooms().add(hallway);
		getRooms().add(staircase);
		getRooms().add(livingRoom);
		getRooms().add(backyard);
		getRooms().add(forest);
		getRooms().add(car);
		getRooms().add(home);

		//objects
		TrappedObject knife = new TrappedObject(0, "knife", "A knife that I put in my pocket last night.\n",0);
		knife.setAlias(new String[]{"blade","cutter","dagger"});
		knife.setPickupable(true);
                knife.setUsable(true);
                knife.setDisposable(true);
                getInventory().add(knife);
		//darkRoom.getObjects().add(knife);
                
                
		TrappedObject key = new TrappedObject(1, "key","A key to unlock the door",0);
		key.setAlias(new String[]{"keys"});
                key.setPickupable(true);
                key.setDisposable(true);
                darkRoom.getObjects().add(key);

		TrappedObject chest= new TrappedObject(2, "chest", "",0);
		chest.setAlias(new String[]{"case","box","crate","package"});
		chest.setPickupable(false);
                chest.setOpenable(true);
		darkRoom.getObjects().add(chest);
                
                TrappedObject wardrobe= new TrappedObject(3, "wardrobe", "",1);
		wardrobe.setAlias(new String[]{"closet","dresser"});
		wardrobe.setPickupable(false);
		hallway.getObjects().add(wardrobe);
                
                TrappedObject cupboard= new TrappedObject(4, "cupboard", "",3);
		cupboard.setAlias(new String[]{"drawer"});
		cupboard.setPickupable(false);
                cupboard.setOpenable(true);
		livingRoom.getObjects().add(cupboard);
                
                TrappedObject axe= new TrappedObject(5, "axe", "An axe that I can use to brak down the door.\n", 3);
		axe.setAlias(new String[]{});
                axe.setPickupable(true);
		axe.setUsable(true);
                axe.setDisposable(true);
		livingRoom.getObjects().add(axe);
                
                TrappedObject stone= new TrappedObject(6, "stone", "",3);
		stone.setAlias(new String[]{"rock"});
		stone.setDisposable(true);
                stone.setPickupable(true);
		stone.setUsable(true);
		livingRoom.getObjects().add(stone);
                
                TrappedObject pliers= new TrappedObject(7, "pliers", "The pliers can cut easily through the fence.\n", 4);
		pliers.setAlias(new String[]{"scissors"});
		pliers.setDisposable(true);
                pliers.setPickupable(true);
		pliers.setUsable(true);
		backyard.getObjects().add(pliers);

		TrappedObject box= new TrappedObject(8, "box", "", 4);
		box.setAlias(new String[]{"case","crate","chest","package"});
                box.setOpenable(true);
		backyard.getObjects().add(box);

		TrappedObject carKey= new TrappedObject(9, "key", "", 6);
		carKey.setAlias(new String[]{"keys", "car"});
		carKey.setPickupable(true);
                carKey.setUsable(true);
		backyard.getObjects().add(carKey);

                TrappedObject tree= new TrappedObject(10, "tree", "", 5);
		tree.setAlias(new String[]{"plant"});
		forest.getObjects().add(tree);

		TrappedObject envelope = new TrappedObject(11, "envelope", "",7);
		envelope.setAlias(new String[]{"case"});
                envelope.setPickupable(true);
                envelope.setOpenable(true);
		home.getObjects().add(envelope);

		TrappedObject note = new TrappedObject(12, "note", "",7);
		note.setAlias(new String[]{"letter","paper"});
		note.setUsable(true);
		home.getObjects().add(note);
                    
                //set starting room and current object
		setCurrentRoom(darkRoom);
		setCurrentObject(knife);
		
        }
	/**
	 * Method that manages, through calls to specific methods, the actions set for each command
     * @param p
     * @return 
	 */
	@Override
	public String nextMove(ParserOutput p) {

		StringBuilder out = new StringBuilder();
		if (p.getCommand() == null && p.getInvObject() == null && p.getObject() == null){
			out.append("I don't understand what do you want to do\n");
		}
		else {
			if (p.getCommand().getType() == CommandType.NORTH) {
				out.append(moveToNorth(p));
			} else if (p.getCommand().getType() == CommandType.SOUTH) {
				out.append(moveToSouth(p));
			}  else if (p.getCommand().getType() == CommandType.EAST) {
				out.append(moveToEast(p));
			} else if (p.getCommand().getType() == CommandType.WEST) {
				out.append(moveToWest(p));
			} else if (p.getCommand().getType() == CommandType.POSITION) {
				out.append(">>YOU ARE IN: "+ getCurrentRoom().getName().toUpperCase()+"\n");
			} else if (p.getCommand().getType() == CommandType.LOOK) {
				out.append(commandLook(p));
			} else if (p.getCommand().getType() == CommandType.TAKE) {
				out.append(commandTake(p));
			} else if (p.getCommand().getType() == CommandType.INVENTORY) {
				out.append(commandInventory(p));
			} else if(p.getCommand().getType() == CommandType.HIDE){
                                out.append(commandHide(p));
                        } else if (p.getCommand().getType() == CommandType.RUN) {
				out.append(commandRun(p));
			} else if (p.getCommand().getType() == CommandType.EQUIP) {
				out.append(commandEquip(p));
			}else if (p.getCommand().getType() == CommandType.USE) { 
				out.append(commandUse(p));
			} else if(p.getCommand().getType() == CommandType.FIND){
				out.append(commandFind(p));
			} else if(p.getCommand().getType() == CommandType.NO){
				out.append(commandNo(p));
			} else if(p.getCommand().getType() == CommandType.YES){
				out.append(commandYes(p));
			} else if(p.getCommand().getType() == CommandType.OPEN) {
				out.append(commandOpen(p));
			} else if(p.getCommand().getType() == CommandType.COMMANDS) {
				out.append(commandCommands(p));
			}	

		}
		return out.toString();
	}

	private String useKnife(ParserOutput p) {
	    StringBuilder out = new StringBuilder();	
            
	     out.append("I reach out to my pocket and to my suprise the knife was still there.\n"
				+ "I managed to cut the rope and free my hands. Then I went to work untying my ankles.\n"
				+ "Once I untied my ankles I stood up and stretched. The room is to dark, I can't see anything.\n");
		
            untied=true;
            return out.toString();
            
        }
        
        
        
        private String turnOnLight(ParserOutput p) {
	    StringBuilder out = new StringBuilder();	
            
            if(getCurrentRoom().isLightNeeded()){
                if(untied){
	     out.append("I struggle to move around the room but just as my eyes adjusted to the darkenss I saw a light switch in the corner.\n"
                     + " I switch it  and the light gets turned on. The room was old and rusty.\n"
                     + "There was a window to my right and a wooden door in front of me. There were cobwebs everywhere.\n"
                     + "The dusty smell made my nose feel tingly. \"Let's just get out of here!\"\n");
		
             getCurrentRoom().setLightNeeded(false);
            }
                else{
                    out.append("I'm tied to a chair. I can't move!\n");
                }
            }
            else{
                out.append("The light is already turned on");
            }
            return out.toString();
	}
        
        private String useKey(ParserOutput p) {
	    StringBuilder out = new StringBuilder();	
            
	     out.append("I put the key in the lock and unlocked the door. \n");
		
            keyUsed=true;
            getCurrentRoom().getNorth().setBlocked(false);
            getCurrentRoom().setDescriptionBlocked("I can't go back, the door is shut.");
            
        
            return out.toString();
	}
        
        private String useAxe(ParserOutput p) {
	    StringBuilder out = new StringBuilder();	
            
	     out.append("I swung the axe and broke the door. I slowly peaked my head out to see if the coast was clear.\n"
                     + " I noticed a shadow move in the backyard of the house.\n"
                     + " Once I looked closer I realised it was some kind of a four legged beast that was lurking in the night.\n"
                     + " The backyard was full of stones and overgrown grass. What should I do to distract the beast? \n");
		
             getCurrentRoom().getEast().setBlocked(false);
        
            return out.toString();
	}
        
        private String useStone(ParserOutput p) {
	    
            StringBuilder out = new StringBuilder();	
            
	     out.append("I threw the stone and the beast started chaising it. \n");
             getCurrentRoom().setBlocked(true);
             getCurrentRoom().setDescriptionBlocked("I finally got out of that house! Why would I go back?\n");
             stoneUsed=true;
             
            return out.toString();
	}
        
        private String usePliers(ParserOutput p){
            
            StringBuilder out = new StringBuilder();	
            
            out.append("I went back to the wire fence and cut it with the pliers. I cut enough wires to make a hole big enough for me to squeeze through.\n"
                    + " I finally got through the fence and started running, never looking back. \n");
            
            getCurrentRoom().getNorth().setBlocked(false);
            getCurrentRoom().setBlocked(true);
            getCurrentRoom().setDescriptionBlocked("I finally escaped that creepy house. Why would I go back?");
            
            return out.toString();
        }
        
        private String useCarKeys(ParserOutput p){
            
            StringBuilder out = new StringBuilder();	
            
                out.append("Just as I turned on the engine the creature started scratching the car trying to get in.\n"
                        + " I quickly drove off leaving the creature behind.\n");
                getCurrentRoom().setBlocked(true);
                getCurrentRoom().setDescriptionBlocked("That creature is probably still in those woods. I can't go back there\n");
                getCurrentRoom().getWest().setBlocked(false);
               
            return out.toString();
        }
        
        private String readNote(ParserOutput p){
            
            StringBuilder out = new StringBuilder();	
            
                out.append("I started reading the note.\n"
                        +"\" Congratulations! You have successfully passed the first part of the test. Prepare for the next one!\".\n"
                        + "\nTO BE CONTINUED...");
                
                p.setEnd(true);
                
                return out.toString();
        }
        
        
        
        private String openObject(ParserOutput p){
            
            StringBuilder out = new StringBuilder();	
            
            if(getCurrentRoom().getId()==0){
                if(p.getObject().getId()==2){
                    out.append("I took the chest from the shelf and opened it. There was an old key inside. \"Finally let's get out of here\".");
                }
            }
            else if(getCurrentRoom().getId()==3){
                if(p.getObject().getId()==4){
                    out.append("I opened the the first drawer and saw an axe laying in it.\n");
                }
            }
            else if(getCurrentRoom().getId()==4){
                if(p.getObject().getId()==8){
                    out.append("I opened the first box and a huge dust cloud flew off. I started coughing and waving my hand in front of my face.\n"
                            + " Once the dust dissipated, I looked into the box. It was filled with broken tools.\n"
                            + " I rummaged through slightly to see if there were any salvageable pieces and I found pliers..\n");
                }
                
            }
            else if(getCurrentRoom().getId()==7){
                if(p.getObject().getId()==11){
                    out.append("I took the envelope and opened it. There was a note inside\n");
                }
                
            }
            
            return out.toString();
        }
        
       /**
	 * Method that manages the command Find
	 */
        private String commandFind(ParserOutput p){
        
                StringBuilder out = new StringBuilder();
         
                if(p.getObject() != null){
                   if(getCurrentRoom().getId()==0){
                    if(p.getObject().getId() == 1 && !getCurrentRoom().isLightNeeded()){
                        out.append("I started looking for a key. The room was rather empty except for a shelf with a chest on the top shelf\n");
                    }
                
                   else{
                       out.append("I can't see in the dark.");
                   }
                   }  
                   if(getCurrentRoom().getId()==4){
                       if(p.getObject().getId() == 7){
                           out.append("I noticed an old shed in the backyard. There were boxes stacked neatly and labeled clearly\n");
                       }
                   }
                }
                else{
                    out.append("I don't understand what do I need to find");
                }
             
            return out.toString();
        }
        
        /**
	 * Method that manages the command Run
	 */
        private String commandRun(ParserOutput p){
            
            StringBuilder out = new StringBuilder();
            
            if(getCurrentRoom().getId() == 5){
                
                out.append("I started running without thinking but it was to dark. I tripped on a branch and when I got up I saw a dark figure standing in front of me.\n" 
                          +"It's skin was blood red and it's eyes were an unnatural gold . It had two large, shiny, black horns growing out the sides of its head.\n"
                        + " Its nose was concave and its teeth were pointed and black. It grabbed me by the neck and I could feel it's long, sharp nails press against my throat.\n"
                        + " I started gasping for air and suddenly everything went black...\n GAME OVER.\n");
                        
                        p.setEnd(true);
            }
            else{
                out.append("Command not valid, try again.\n");
            }
            
            return out.toString();
                
            }
            
        
        /**
	 * Method that manages the command Hide
	 */
        private String commandHide(ParserOutput p){
            
            StringBuilder out = new StringBuilder();
            
            if(p.getObject() != null){
                 if(getCurrentRoom().getId()==1){
                    if(p.getObject().getId() == 3){
                        out.append("I quickly opened the wardrobe and hid inside. After what felt like an hour I mustered up the courage and opened the door.\n "
                                + "The silhouette I saw before was nowhere to be seen now. \"That was close, I whispered.\n");
                        getCurrentRoom().getEast().setBlocked(false);
                    }
                                        
                }
                 else if(getCurrentRoom().getId()==5){
                     if(p.getObject().getId() == 10){
                        out.append("I hid behind the tree and listened carefully. Dead silence was surrounding me and the only thing I could hear was my own breathing.\n"
                                + " Just as I started relaxing I heard footsteps and a loud sinister laugh. I peeked carefully and saw a weird creature passing me by.\n"
                                + " I waited for a few more minutes until I was sure it was gone.\n");
                        
                        getCurrentRoom().getNorth().setBlocked(false);
                        getCurrentRoom().setBlocked(true);
                        getCurrentRoom().setDescriptionBlocked("I really don't think it's a good idea going back there!");
                    }
                 }
        }
            else{
                out.append("I don't undestand where do you want me to hide");
            }
            
            return out.toString();
        }
        

        
        
	private TrappedObject readInventory(int i) {
		return getInventory().get(i);
	}

	


	/**
	 * Method that manages the command North
	 */
	private String moveToNorth(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(p.getObject()!=null || p.getInvObject()!=null) {
			out.append("You cannot move objects!");
		}

		else {
			if (getCurrentRoom().getNorth() != null) {
				if(getCurrentRoom().getNorth().isBlocked()){
					out.append(getCurrentRoom().getNorth().getDescriptionBlocked());
				}else {
					setCurrentRoom(getCurrentRoom().getNorth());
					out.append(">>You moved north.\n"+ getCurrentRoom().getDescription());
				}
			} else {
				out.append("You cannot move in this direction\n");
			}
		}
		return out.toString();
	}

	/**
	 * Method that manages the command South
	 */
	private String moveToSouth(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(p.getObject()!=null || p.getInvObject()!=null) {
			out.append("You cannot move objects!");
		}

		else {
			if (getCurrentRoom().getSouth() != null) {
				if(getCurrentRoom().getSouth().isBlocked()){
					out.append(getCurrentRoom().getSouth().getDescriptionBlocked());
				}else {
					setCurrentRoom(getCurrentRoom().getSouth());
					out.append(">>You moved south.\n"+ getCurrentRoom().getDescription());
				}
			} else {
				out.append("You cannot move in this direction\n");
			}
		}
		return out.toString();
	}

	/**
	 * Method that manages the command East
	 */
	private String moveToEast(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(p.getObject()!=null || p.getInvObject()!=null) {
			out.append("You cannot move objects!");
		}

		else {
			if (getCurrentRoom().getEast() != null) {
				if(getCurrentRoom().getEast().isBlocked()){
					out.append(getCurrentRoom().getEast().getDescriptionBlocked());
				}else {
                                        if(getCurrentRoom().getId()==3 && !stoneUsed){
                                            out.append("I went out of the house. As soon as I stepped out the beast heard me and started running towards me. \n"
                                                     + "I tried to escape but it was too fast. It bit my leg and knocked me on the ground.\n"
                                                     + "I could feel it's long, sharp teeth press against my throath. I started gasping for air and suddenly everything went balck....\n GAME OVER. \n");
                                                     p.setEnd(true);
                                        }
					setCurrentRoom(getCurrentRoom().getEast());
					out.append(">>You moved east.\n"+ getCurrentRoom().getDescription());
				}
			} else {
				out.append("You cannot move in this direction\n");
			}
		}
		return out.toString();
	}

	/**
	 * Method that manages the West command
	 */
	private String moveToWest(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(p.getObject()!=null || p.getInvObject()!=null) {
			out.append("You cannot move objects!");
		}

		else {
			if (getCurrentRoom().getWest() != null) {
				if(getCurrentRoom().getWest().isBlocked()){
					out.append(getCurrentRoom().getWest().getDescriptionBlocked());
				}
				else{
					setCurrentRoom(getCurrentRoom().getWest());
					out.append(">>You moved west.\n"+ getCurrentRoom().getDescription());
				}
			} else {

					out.append("You cannot move in this direction.\n");
			}
		}
		return out.toString();
	}

	/**
	 * Method that manages the Look command
	 */
	private String commandLook(ParserOutput p) {

		StringBuilder out = new StringBuilder();
		//look object
		     if(p.getObject() != null) {
			if(getCurrentRoom().isLightNeeded()) {		
                		out.append("You can't see in the dark!");
                        }else {
				out.append(p.getObject().getDescription());
			}
		} //look object inventory
		else if(p.getInvObject() != null) {
			if(getCurrentRoom().isLightNeeded()) {
                                out.append("I can't see in the dark\n");
			}else {
				out.append(p.getInvObject().getDescription());
			}
		} //command look
		else {
			if(getCurrentRoom().getLook() != null) {
				if(getCurrentRoom().isLightNeeded()) {
                                        out.append("I can't see in the dark\n");
				}else {
					out.append(getCurrentRoom().getLook());
				}
			}else {
				getCurrentRoom().getDescription();
			}
		} 
		return out.toString();
	}

	/**
	 * Method that manages the command Take
	 */
	private String commandTake(ParserOutput p) {

		StringBuilder out = new StringBuilder();
		if (p.getObject() != null) {
                    if(!getCurrentRoom().isLightNeeded()){
			if (p.getObject().isPickupable()) {
				
				getInventory().add(p.getObject());
				getCurrentRoom().getObjects().remove(p.getObject());
				out.append(">>You took: " + p.getObject().getName()+"\n");
                                
                                if(p.getObject().getId() == 9) {
					keyTaken = true;
				}
                                if(p.getObject().getId() == 5) {
					out.append("Now that I have the axe I can use it to slam the door so I can finally get out of this house.\n");
				}
                                if(p.getObject().getId() == 7){
                                    out.append("I took the pliers and continued searching inside the box to find if there was something else that could be useful.\n"
                                            + " I noticed a key at the bottom of the box. Should I take it with me?\n");
                                }
			} else {
				
				out.append("You cannot take this object!\n");
			}
                    }
                    else{
                        out.append("I can't see in the dark!\n");
                    }
		} 
		
		else {
			out.append("I don't understand what do you want to take.\n");
		}
		return out.toString();
	}

	/**
	 * Method that manages the command Inventory
	 */
	private String commandInventory(ParserOutput p) {

		StringBuilder out = new StringBuilder();
		if (getInventory().size() > 0) {
			emptyInventory=false;
		}
		else {
			emptyInventory=true;
		}
		if (!emptyInventory) {
			for(int i = 0; i < getInventory().size(); i++) {
				
				if(readInventory(i).getName() == getCurrentObject().getName()) {
					out.append("  -"+readInventory(i).getName()+"\t(equipped)\n"); 
				}
				else {
					out.append("  -"+readInventory(i).getName()+"\n");
				}
			}
		}else{
			out.append("Your inventory is empty.\n");
		}

		return out.toString();
	}

	/**
	 * Method that manages the command Equip
	 */
	private String commandEquip(ParserOutput p) {
            
            StringBuilder out = new StringBuilder();
		
		if (p.getInvObject() != null) {
			//exchange the current item from hand to inventory
			//exchange the requested item from inventory to hand
			if(objectEquipped) {
				if(p.getInvObject().getId() == getCurrentObject().getId()) {
					out.append("You have already equipped this object!\n");
				}
				else {
					out.append(">>You put in your inventory "+getCurrentObject().getName());
					setCurrentObject(p.getInvObject());
					out.append(" and you equipped "+getCurrentObject().getName()+".\n");
				}
			}else{
				setCurrentObject(p.getInvObject());
				out.append(">>You equipped " + getCurrentObject().getName()+"\n");
				objectEquipped=true;
			}

		} else {
			out.append("I don't understand what do you want to take from the inventory. Visualise your inventory to see what you have.");
		}	

		return out.toString();
	}

	/**
	 * Method that manages the command Use
	 */
	private String commandUse(ParserOutput p) {

		StringBuilder out = new StringBuilder();
		if (p.getInvObject() != null && p.getObject() == null) {
			if(p.getInvObject().isUsable()) {
				if (objectEquipped) {
					for(int i=0; i<getInventory().size(); i++) {
					
						if(readInventory(i).equals(getCurrentObject()) && p.getInvObject() == getCurrentObject()){
							equipped=true;

							break;
						} else {
							equipped=false;
						}
					}
					if(!equipped) {
						out.append(">>You cannot use it, you have equipped "+getCurrentObject().getName()+".\n");	
					}else{

						if(getCurrentObject().getIdRoom() == getCurrentRoom().getId()) {
                                                   
							out.append(">>You used " + getCurrentObject().getName()+".\n");
						
							//if the object is disposable, it will be disposed by default
							if(getCurrentObject().isDisposable()) {
				
									out.append("You dropped the object "+getCurrentObject().getName()+", you won't need it anymore...\n");						
								
								objectEquipped=false;
								getInventory().remove(getCurrentObject());
							} 

							if(getCurrentRoom().getId() == 0) {
									if(p.getInvObject().getId() == 0) {	
                                                                            out.append(useKnife(p));   
									}
                                                        
                                                                        else if(p.getInvObject().getId() == 1) {
										if(!getCurrentRoom().isLightNeeded()){
										out.append(useKey(p));	
								}
                                                                        else{
                                                                            out.append("The room is too dark. I can't see anything");
                                                                        }
							}
                                                        }
                                                        
							 if(getCurrentRoom().getId() == 3) {
								if(p.getInvObject().getId() == 5) {
									out.append(useAxe(p));
								}
                                                                else if(p.getInvObject().getId() == 6){
                                                                        out.append(useStone(p));
                                                                }
                                                                        
                                                                 
						}
                                                        else if(getCurrentRoom().getId() == 4) { 
								if(p.getInvObject().getId() == 7) {
									out.append(usePliers(p));
        
								}
                                                                
						}
                                               
                                                        else if(getCurrentRoom().getId() == 6) {
								if(p.getInvObject().getId() == 9) {
									out.append(useCarKeys(p));
								}
                                                                
						}
                                                        else if(getCurrentRoom().getId() == 7) {
								if(p.getInvObject().getId() == 12) {
									out.append(readNote(p));
								}
                                                                
						}
					
                                                }
                                                else{
                                                    out.append("What do you want to use it for?\n");
                                                }
                                        }
				}else{
					out.append(">>You cannot use it. You haven't equipped any object.\n");
				}
			}else {
				out.append("You cannot use this object.\n");
			}
                        }else if (p.getObject() != null && p.getInvObject() == null){
			out.append("You cannot use an object if it is not present in the inventory!\n");
                        
                        }else if(getCurrentRoom().getId() == 6 && !keyTaken){
                            out.append("I realised that I didn't take the key of the car. It was impossible now to open the door.\n"
                        + "  The creature was noe standing right behind me. I tried to run but it grabbed me and stabbed me with it's long sharp nails right in my chest.\n"
                        + " I started choking on my own blood and soon I lost consciousness. \n GAME OVER. \n");
                        p.setEnd(true);
                        }
		       else if(getCurrentRoom().isLightNeeded()){
                            out.append(turnOnLight(p));
                        }
		else {
			out.append("Command not accepted!\n");
		}

		return out.toString();
            
        }
        

        


	/**
	 * Method that manages the command No
	 */
	private String commandNo(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(getCurrentRoom().getId()==2) {
                        out.append("You're right. It looks like a trap. I should try to find an exit downstairs.\n");
                        getCurrentRoom().setBlocked(true);
                        getCurrentRoom().setDescriptionBlocked("I really shouldn't go up there. That voice calling for help was probably a trap!\n");
			getCurrentRoom().getSouth().setBlocked(false);
                        setCurrentRoom(getCurrentRoom().getSouth());
                        out.append(getCurrentRoom().getDescription());
		}
                else if(getCurrentRoom().getId()==4){
			out.append("I left the key in the box. Now that I have the pliers I can use them to cut the fence so I can finally get out of here!.\n");
		}
                else{
                    out.append("Who are you talking with?\n");
                }

		return out.toString();
	}

	/**
	 * Method that manages the command Yes
	 */
	private String commandYes(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(getCurrentRoom().getId()==2) {
			out.append("I walked up the staircase. My heart was pounding and I was breathing shakily. Before I could reach the end of the stairs a silhouette took shape at the edge of the darkness.\n"
                                + " I couldn't make out much, just that whatever it was, it didn't seem to be human. The figure whimpered and stepped out of the darkness. It's skin was blood red and it's eyes were an unnatural gold .\n"
                                + " It had two large, shiny, black horns growing out the sides of its head. Its nose was concave and its teeth were pointed and black. It grabbed me by the neck and I could feel it's long, sharp nails press against my throat.\n"
                                + " I started gasping for air and suddenly everything went black...\n GAME OVER. \n");
                        p.setEnd(true);
		}
                else if(getCurrentRoom().getId()==4){
                               out.append("You are probably right. I should take it");
                               
		}
                else{
                    out.append("Who are you talking with?\n");
                }

		return out.toString();
	}

	/**
	 * Method that manages the command Open
	 */
	private String commandOpen(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(p.getObject() != null) {
                    if(!getCurrentRoom().isLightNeeded()){
			if(p.getObject().isOpenable()) {
				
				out.append(">>You opened "+ p.getObject().getName()+".\n");
                                out.append(openObject(p));
			}
			else {
				out.append(p.getObject().getName() + " cannot be opened.\n");
			}
                }
                    else{
                        out.append("I cant't see in the dark\n");
                    }
		}
		
		else if(p.getInvObject() != null && p.getObject() == null) {
			out.append(p.getInvObject().getName() + " cannot be opened.\n");
		}
		else if(getCurrentRoom().getId() == 0){
                        if(!getCurrentRoom().isLightNeeded()){
				if(!keyUsed) {
					out.append("I went to the door and tried the handle, it was locked");
				}
				else {
					out.append("I slowly pushed the door and it swung open and slammed against the wall.\n");
                                        getCurrentRoom().getNorth().setBlocked(false);
                                        getCurrentRoom().setBlocked(true);
                                        getCurrentRoom().setDescriptionBlocked("I can't go back. The door is shut.");
                                        
				}
                        }
                        else{
                            out.append("I can't see in the dark\n");
                        }
              } else if(getCurrentRoom().getId() == 6) {
				if(!keyTaken) {
                                        out.append("I realised that I didn't take the key of the car from. It was impossible now to open the door.\n"
                                        + "  The creature was noe standing right behind me. I tried to run but it grabbed me and stabbed me with it's long sharp nails right in my chest.\n"
                                        + " I started choking on my own blood and soon I lost consciousness. \n GAME OVER. \n");
                                         p.setEnd(true);
                        }
				
				else {
					out.append("I opened the car door and got inside.\n");
                                        out.append(useCarKeys(p));
				}
			}
			else {
				out.append("Command not valid, try again.\n");
			}
		

		return out.toString();
        }



	/**
	 * Method that manages the command Commands
	 */
	private String commandCommands(ParserOutput p) {

		StringBuilder out = new StringBuilder();

		if(p.getInvObject() == null && p.getObject() == null) {
			out.append("NORTH-> Move to north\n" + "SOUTH-> Move to south\n" + "EAST-> Move to east\n"
					+ "WEST-> Move to west\n" + "POSITION-> See your position\n"
					+ "EXIT-> Exit the game\n" + "LOOK-> look at the room or an object\n"
					+ "TAKE-> Take an object\n" + "INVENTORY-> Visualise your inventory\n"
					+ "EQUIP-> Take an object in your hand\n" 
					+ "USE-> Use an object.\n" 
					+ "FIND-> Find an object\n"
					+ "OPEN-> Open objects\n" + "HIDE-> Hide behind an object\n"
					+ "NO-> Respond no\n" + "YES-> Respond yes\n"
                                        + "RUN-> Run away\n"
					+ "\nPS.Before using an object you need to equip it.\n");
		}
		else {
			out.append("The command entered is not valid.\n");
		}

		return out.toString();
	}


}


